window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['LineControl'] = {
  initialData: {
      size: 1,
      color: "#000000",
      width: "320",
      angle: "0"
  },
  propertyWindowCallback: function(ractiveControl){}
};
