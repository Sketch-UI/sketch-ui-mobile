window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ToolbarControl'] = {
  initialData: {
      bgcolor: "#4a87ee",
      height: "44"
  },
  propertyWindowCallback: function(ractiveControl){}
};
