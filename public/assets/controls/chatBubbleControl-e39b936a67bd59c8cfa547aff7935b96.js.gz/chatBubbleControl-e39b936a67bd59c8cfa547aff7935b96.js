window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ChatBubbleControl'] = {
  initialData: {
      bg_color: "rgb(238, 184, 61)",
      text_color: "#000000",
      caption: "Hey Buddy! Have a great day",
      right_bubble: false,
      top_pointer:true

  },
  propertyWindowCallback: function(ractiveControl){}
};
