window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['KeyboardControl'] = {
  initialData: {
      phone: 'android.png'
  },
  propertyWindowCallback: function(ractiveControl){}
};
