window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['TimepickerControl'] = {
  initialData: {
      width: '100'
  },
  propertyWindowCallback: function(ractiveControl){}
};
