window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ToggleControl'] = {
    initialData: {
        on_color: '#4a87ee' ,
        off_color: '#e5e5e5'

    },
    propertyWindowCallback: function (ractiveControl) {
    }
};
