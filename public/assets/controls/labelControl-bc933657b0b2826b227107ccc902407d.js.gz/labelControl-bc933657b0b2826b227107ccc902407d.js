window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['LabelControl'] = {
  initialData: {
    color: "#000000",
    size: "24",
    label: "Hello World",
    font: "Arial"
  },
  propertyWindowCallback: function(ractiveControl){
  }
};
