window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['RangeControl'] = {
  initialData: {
      width: 200,
      color: "#000000"
  },
  propertyWindowCallback: function(ractiveControl){}
};
