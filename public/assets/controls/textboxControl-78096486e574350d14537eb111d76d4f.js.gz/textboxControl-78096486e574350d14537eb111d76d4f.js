window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['TextboxControl'] = {
  initialData: {
      width: "300",
      height: "34",
      font: "Arial",
      place_holder: "Enter User Name"
  },
  propertyWindowCallback: function(ractiveControl){}
};
