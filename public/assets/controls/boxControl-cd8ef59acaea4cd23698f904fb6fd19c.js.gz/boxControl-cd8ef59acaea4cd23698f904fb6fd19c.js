window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['BoxControl'] = {
  initialData: {
      size: 1,
      color: "#000000",
      width: "70",
      height: "60",
      bg_color: "#4a87ee",
      border_radius: 0
  },
  propertyWindowCallback: function(ractiveControl){}
};
