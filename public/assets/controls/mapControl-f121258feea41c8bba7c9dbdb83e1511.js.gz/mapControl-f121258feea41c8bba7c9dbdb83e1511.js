window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['MapControl'] = {
  initialData: {
      width: 300,
      height: 200
  },
  propertyWindowCallback: function(ractiveControl){}
};
