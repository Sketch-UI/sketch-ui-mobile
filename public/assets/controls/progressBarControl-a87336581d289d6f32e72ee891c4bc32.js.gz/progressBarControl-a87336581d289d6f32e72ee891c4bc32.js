window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ProgressBarControl'] = {
  initialData: {
      width: 200,
      percentage_complete: "50"
  },
  propertyWindowCallback: function(ractiveControl){}
};
