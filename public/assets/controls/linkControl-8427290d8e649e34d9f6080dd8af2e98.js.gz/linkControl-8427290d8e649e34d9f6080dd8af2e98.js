window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['LinkControl'] = {
  initialData: {
      text: "Link text",
      bg_color: '#4a87ee',
      color: 'black',
      font_weight: "normal",
      font_style: "normal",
      font: "Arial"
  },
  propertyWindowCallback: function(ractiveControl){}
};
