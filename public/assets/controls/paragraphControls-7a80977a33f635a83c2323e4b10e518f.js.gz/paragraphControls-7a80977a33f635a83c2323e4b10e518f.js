window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ParagraphControls'] = {
  initialData: {
      text: "paragraph control",
      width: "320",
      height: "100",
      align: "left"
  },
  propertyWindowCallback: function(ractiveControl){}
};
