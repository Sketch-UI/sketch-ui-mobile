window.ControlsMetadata = window.ControlsMetadata || {};
window.ControlsMetadata['ButtonControl'] = {
  initialData: {
      button_label: "Button",
      bgcolor: "#428bca",
      color: "#ffffff",
      width: 90,
      height: 25,
      font_weight: "normal",
      font_style: "normal",
      font: "Arial"
  },
  propertyWindowCallback: function(ractiveControl){
  }
};
